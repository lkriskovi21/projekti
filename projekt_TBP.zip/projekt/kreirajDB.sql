BEGIN;

CREATE TABLE User_Types (
    type_id SERIAL PRIMARY KEY,
    type_name VARCHAR(50) UNIQUE NOT NULL
);
CREATE TABLE
baza=# CREATE TABLE Users (
    user_id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password TEXT NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    type_id INT REFERENCES User_Types(type_id) ON DELETE SET NULL,
    full_name VARCHAR(100)
);

CREATE TABLE Subjects (
    subject_id SERIAL PRIMARY KEY,
    subject_name VARCHAR(100) NOT NULL
);
CREATE TABLE Teacher_Subjects (
    user_id INT REFERENCES Users(user_id) ON DELETE CASCADE,
    subject_id INT REFERENCES Subjects(subject_id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, subject_id)
);
CREATE TABLE Student_Subjects (
    user_id INT REFERENCES Users(user_id) ON DELETE CASCADE,
    subject_id INT REFERENCES Subjects(subject_id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, subject_id)
);
CREATE TABLE Parent_Students (
    parent_id INT REFERENCES Users(user_id) ON DELETE CASCADE,
    student_id INT REFERENCES Users(user_id) ON DELETE CASCADE,
    PRIMARY KEY (parent_id, student_id)
);
CREATE TABLE user_metadata (
    metadata_id SERIAL PRIMARY KEY,
    user_id INT NOT NULL,
    registration_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    phone_number VARCHAR(15),
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE
);

CREATE TABLE Grades (
    grade_id SERIAL PRIMARY KEY,
    student_id INT REFERENCES Users(user_id) ON DELETE CASCADE,
    subject_id INT REFERENCES Subjects(subject_id) ON DELETE CASCADE,
    grade INT,
    grade_date DATE NOT NULL,
    teacher_note TEXT
);
CREATE TABLE subjects_with_main_teacher (
    main_teacher_id INTEGER REFERENCES users(user_id)
) INHERITS (subjects);



INSERT INTO Users (username, password, email, type_id, full_name)
VALUES
('kmrvi', 'koprvi123', 'mrvi@gmail.com', 1, 'Karmelo Mrvi'),
('nkrisnik', 'nina123', 'nkrsnik@gmail.com', 2, 'Nina Krsnik'),
('ivlasic', 'nivea123', 'ivalsic@gmail.com', 3, 'Ivan Vlasic'),
('lnizic', 'krse123', 'lnizic@gmail.com', 4, 'Luka Nizic');

INSERT INTO Users (username, password, email, type_id, full_name)
VALUES
('vdokovic', 'limes123', 'vdokovic@gmail.com', 1, 'Vedrana Đokovic'),
('rhrkovac', 'rebi123', 'rhrkovac@gmail.com', 2, 'Rebeka Hrkovac'),
('mstura', 'marino123', 'mstura@gmail.com', 2, 'Marino Štura'),
('lkriskovic', 'laura123', 'lkriskovi@gmail.com', 2, 'Laura Kriskovic');

INSERT INTO Users (username, password, email, type_id, full_name)
VALUES
('angelina', 'ina123', 'angelina@gmail.com', 1, 'Angelina Doria'),
('hegi', 'hegi123', 'hegi@gmail.com', 1, 'Franko Hegeduš'),
('salajbeg', 'sara123', 'salajbeg@gmail.com', 3, 'Sara Alajbeg'),
('rmatekovic', 'ruza123', 'rmatekovic@gmail.com', 3, 'Ruža Matekovic');

 INSERT INTO Users (username, password, email, type_id, full_name)
VALUES
('matucec', 'zeljka123', 'matucec@gmail.com', 1, 'Željka Matucec'),
('krebic', 'rebic123', 'krebic@gmail.com', 1, 'Kruno Rebic');

INSERT INTO Subjects (subject_name)
VALUES
('Engleski'),
('Hrvatski'),
('Matematika',
('Biologija'),
('Tjelesni'),
('Povijest');

INSERT INTO Teacher_Subjects (user_id, subject_id)
VALUES
(5, 5),
(9, 3), (13,1),(14,2),(17, 4),
(18, 6);

INSERT INTO Student_Subjects (user_id, subject_id)
VALUES
(7,1),(7,2),(7,3),(7,4),(7,5),(10,2),(10,1),(11,4),(11,6),(11,3),(12,1),(12,2),(12,3);
INSERT INTO Parent_Students (parent_id, student_id)
VALUES
(6, 11),(8,12),(15,10),(16,7);

 INSERT INTO Grades (student_id, subject_id, grade, grade_date)
VALUES
(7, 4, 1, '2025-01-17'),
(7, 3, 5, '2025-01-17'),(7, 2, 4, '2025-01-17'),(7, 3, 4, '2025-01-17'),(10, 2, 5, '2025-01-17'),(10, 1, 2, '2025-01-17'),(11, 3, 5, '2025-01-17'),(11, 6, 4, '2025-01-17'),(11, 4, 5, '2025-01-17'),(12, 2, 5, '2025-01-17');

CREATE TABLE subjects_with_main_teacher (
    main_teacher_id INTEGER REFERENCES users(user_id)
) INHERITS (subjects);


INSERT INTO subjects_with_main_teacher (subject_id, subject_name, main_teacher_id)
VALUES (1, 'Engleski', 13);
INSERT INTO subjects_with_main_teacher (subject_id, subject_name, main_teacher_id)
VALUES (2, 'Hrvatski', 14);
INSERT INTO subjects_with_main_teacher (subject_id, subject_name, main_teacher_id)
VALUES (3, 'Matematika', 9);

INSERT INTO subjects_with_main_teacher (subject_id, subject_name, main_teacher_id)
VALUES (4, 'Biologija', 17);
INSERT INTO subjects_with_main_teacher (subject_id, subject_name, main_teacher_id)
VALUES (5, 'Tjelesni', 5);
baza=# INSERT INTO subjects_with_main_teacher (subject_id, subject_name, main_teacher_id)
VALUES (6, 'Povijest', 18);

INSERT INTO user_types(type_id, type_name) VALUES('4', 'Admin');
INSERT INTO users(username, password, email, type_id,full_name) VALUES('linmanuel', 'miranda', 'lmm@gmail.com', '4','Lin Manuel Miranda');

INSERT INTO user_metadata(user_id, phone_number) VALUES ('5','+38528718723'), ('6','+385287242343'),('8','+38523453723'),('16','+383452354'),('7','+38528718723'),('9','+385282922'),('10','+38525555'),('11','+385288823'),('12','+3811111113'),('13','+38526562');
INSERT INTO user_metadata(user_id, phone_number) VALUES ('20','+385254723'), ('18','+31187242343'),('7','+385553723'),('15','+38444354'),('14','+3822222723');


from flask import Flask, jsonify, render_template, request, redirect, session, flash, url_for
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.secret_key = '1ac48208de2e01a9192cb6ae094fa1b55afc4e532829864e'
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://laura:laura@localhost/baza'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Users(db.Model):
    __tablename__ = 'users'
    user_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.Text, nullable=False)
    type_id = db.Column(db.Integer, db.ForeignKey('user_types.type_id'), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)

class UserTypes(db.Model):
    __tablename__ = 'user_types'
    type_id = db.Column(db.Integer, primary_key=True)
    type_name = db.Column(db.String(50), unique=True, nullable=False)

class Subjects(db.Model):
    __tablename__ = 'subjects'
    subject_id = db.Column(db.Integer, primary_key=True)
    subject_name = db.Column(db.String(100), nullable=False)

class SubjectsWithMainTeacher(db.Model):
    __tablename__ = 'subjects_with_main_teacher'
    subject_id = db.Column(db.Integer, db.ForeignKey('subjects.subject_id'), primary_key=True)
    main_teacher_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)

class TeacherSubjects(db.Model):
    __tablename__ = 'teacher_subjects'
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), primary_key=True)
    subject_id = db.Column(db.Integer, db.ForeignKey('subjects.subject_id'), primary_key=True)

class StudentSubjects(db.Model):
    __tablename__ = 'student_subjects'
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), primary_key=True)
    subject_id = db.Column(db.Integer, db.ForeignKey('subjects.subject_id'), primary_key=True)

class Grades(db.Model):
    __tablename__ = 'grades'
    grade_id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)
    subject_id = db.Column(db.Integer, db.ForeignKey('subjects.subject_id'), nullable=False)
    grade = db.Column(db.Integer, nullable=False)
    grade_date = db.Column(db.Date, nullable=False)
    teacher_note  = db.Column(db.Text)
    student = db.relationship('Users', backref='grades')
    subject = db.relationship('Subjects', backref='grades')

class ParentStudents(db.Model):
    __tablename__ = 'parent_students'
    parent_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), primary_key=True)
    parent = db.relationship('Users', foreign_keys=[parent_id], backref='children')
    student = db.relationship('Users', foreign_keys=[student_id], backref='parents')

class UserMetadata(db.Model):
    __tablename__ = 'user_metadata'

    metadata_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)
    registration_date = db.Column(db.DateTime, default=db.func.current_timestamp())
    phone_number = db.Column(db.String(15))
    user = db.relationship('Users', backref='metadata', uselist=False)


@app.route('/')
def main():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    if 'user_id' in session:
        user = Users.query.get(session['user_id'])
        full_name = user.full_name
    
        if user.type_id == 1:  
            user_role = 'professor'
            subjects = TeacherSubjects.query.filter_by(user_id=user.user_id).all()
            subject_grades = []
            students = []
            subject_students = []

            for subject in subjects:
                subject_name = Subjects.query.get(subject.subject_id).subject_name
                grades = db.session.query(Users.full_name, Grades.grade, Grades.grade_id)\
                    .join(Grades, Users.user_id == Grades.student_id)\
                    .filter(Grades.subject_id == subject.subject_id).all()
                
                students = db.session.query(Users.full_name, Users.user_id).join(StudentSubjects, StudentSubjects.user_id == Users.user_id) \
                    .filter(Users.type_id == 2, StudentSubjects.subject_id == subject.subject_id).all()

                subject_grades.append({'subject_name': subject_name, 'grades': grades})

            return render_template('main.html', full_name=full_name, user_role=user_role, subject_grades=subject_grades, students = students)
        

        elif user.type_id == 2: 
            user_role = 'student'
            student_subjects = db.session.query(Subjects.subject_name, Grades.grade).\
                join(StudentSubjects, StudentSubjects.subject_id == Subjects.subject_id).\
                join(Grades, Grades.subject_id == Subjects.subject_id).\
                filter(StudentSubjects.user_id == user.user_id).\
                all()
            subject_grades = {}
            for subject_name, grade in student_subjects:
                if subject_name not in subject_grades:
                    subject_grades[subject_name] = []
                subject_grades[subject_name].append(grade)
            
            subject_averages = {}
            for subject, grades in subject_grades.items():
                average = sum(grades) / len(grades) 
                subject_averages[subject] = round(average, 2)

            return render_template('main.html', subject_averages=subject_averages, full_name=full_name, user_role=user_role, subject_grades=subject_grades)

            
        elif user.type_id == 3: 
            user_role = 'parent'
            # Dohvati dijete roditelja
            child = db.session.query(Users).join(ParentStudents, ParentStudents.student_id == Users.user_id)\
                .filter(ParentStudents.parent_id == user.user_id).first()
            if child:
                grades_by_subject = db.session.query(
                Subjects.subject_name,
                Grades.grade,
                Grades.teacher_note,
                Grades.subject_id
            ).join(Subjects, Subjects.subject_id == Grades.subject_id)\
            .filter(Grades.student_id == child.user_id).all()
            max_columns = 0
            subject_data = {}
            for subject_name, grade, teacher_note, subject_id in grades_by_subject:
                if subject_name not in subject_data:
                    subject_data[subject_name] = {'grades': [], 'notes': [], 'average': 0}
                subject_data[subject_name]['grades'].append(grade)
                subject_data[subject_name]['notes'].append(teacher_note)
                subject_data[subject_name]['average'] = round(sum(subject_data[subject_name]['grades']) / len(subject_data[subject_name]['grades']), 2)

            for subject_name, data in subject_data.items():
                grades = data['grades']
                data['average'] = round(sum(grades) / len(grades), 2) if len(grades) > 0 else None
                max_columns = max(max_columns, len(grades))  


            return render_template(
                'main.html',
                full_name=full_name,
                user_role=user_role,
                child_name=child.full_name,
                subject_data=subject_data,
                max_columns=max_columns
            )
        else:
            flash("Nije pronađeno dijete povezano s ovim korisnikom!", "error")
            return redirect('/login')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = Users.query.filter_by(username=username).first()
        if user and user.password == password:
            session['user_id'] = user.user_id
            session['type_id'] = user.type_id  
            if user.type_id == 4: 
                return redirect('/admin_dashboard') 
            else:
                return redirect('/')
        else:
            flash('Neispravno korisničko ime ili lozinka!', 'error')
            return redirect('/login')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear() 
    return redirect(url_for('login'))

@app.route('/add_grade', methods=['GET', 'POST'])
def add_grade():
    if 'user_id' not in session:
        return redirect('/login')

    user = Users.query.get(session['user_id'])
    if user.type_id != 1:  
        return redirect('/')

    if request.method == 'POST':
        try:
            student_id = int(request.form['student_id']) 
            grade = request.form['grade']
            teacher_note = request.form.get('teacher_note', None) 

            subject = db.session.query(Subjects).join(TeacherSubjects).filter(
                TeacherSubjects.user_id == user.user_id
            ).first()

            if not subject:
                return redirect('/')

            subject_id = subject.subject_id 

            student = db.session.query(Users).join(StudentSubjects).filter(
                StudentSubjects.subject_id == subject_id,
                StudentSubjects.user_id == student_id
            ).first()

            if not student:
                return redirect('/')

            date = datetime.now().strftime('%Y-%m-%d')  
            new_grade = Grades(
                student_id=student_id,
                subject_id=subject_id,
                grade=grade,
                teacher_note=teacher_note,
                grade_date=date
            )
            db.session.add(new_grade)
            db.session.commit()

            return redirect('/')
        except Exception as e:
            return redirect('/')

    subjects = db.session.query(Subjects).join(TeacherSubjects).filter(
        TeacherSubjects.user_id == user.user_id
    ).all()


    subject_students = [] 
    for subject in subjects:
        students = db.session.query(Users.full_name, Users.user_id).join(StudentSubjects)\
            .filter(StudentSubjects.subject_id == subject.subject_id).all()
        subject_students.append({'subject_name': subject.subject_name, 'students': students})

    current_date = datetime.now().strftime('%Y-%m-%d')  # Današnji datum

    return render_template('main.html', user_role='professor', subject_students=subject_students, current_date=current_date)

@app.route('/delete_grade/<int:grade_id>', methods=['POST'])
def delete_grade(grade_id):
    if 'user_id' not in session:
        return redirect('/login')

    user = Users.query.get(session['user_id'])
    if not user or user.type_id != 1:
        flash('Pristup nije dozvoljen!', 'error')
        return redirect('/login')

    grade = Grades.query.get(grade_id)
    if not grade:
        flash('Ocjena nije pronađena!', 'error')
        return redirect('/')

    main_teacher = SubjectsWithMainTeacher.query.filter_by(subject_id=grade.subject_id, main_teacher_id=user.user_id).first()
    if not main_teacher:
        flash('Samo glavni nositelj predmeta može obrisati ocjenu!', 'error')
        return redirect('/')

    try:
        db.session.delete(grade)
        db.session.commit()
        flash('Ocjena je uspješno obrisana!', 'success')
        return jsonify({"success": True}), 200
    except Exception as e:
        db.session.rollback()
        flash('Dogodila se greška prilikom brisanja ocjene!', 'error')
        return jsonify({"success": False, "error": "Error deleting grade"}), 500
    
@app.route('/admin_dashboard', methods=['GET'])
def admin_dashboard():
    if 'user_id' not in session:
        return redirect('/login')
    
    user = Users.query.get(session['user_id'])
    if not user or user.type_id != 4:  
        flash('Pristup nije dozvoljen!', 'error')
        return redirect('/')

    users_with_metadata = db.session.query(
        Users.full_name, Users.email, UserMetadata.phone_number, Users.user_id, UserMetadata.registration_date, 
    ).join(UserMetadata, Users.user_id == UserMetadata.user_id).all()

    return render_template('admin.html', users_with_metadata=users_with_metadata)

@app.route('/add_user', methods=['GET', 'POST'])
def add_user():
    if 'user_id' not in session or session['type_id'] != 4:
        flash('Pristup nije dozvoljen!', 'error')
        return redirect('/login')

    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password') 
        full_name = request.form.get('full_name')
        phone_number = request.form.get('phone_number')
        type_id = request.form.get('type_id', type=int)

        if not (username and email and password and full_name and type_id):
            flash('Sva obavezna polja moraju biti ispunjena!', 'error')
            return redirect('/add_user')
        new_user = Users(username=username, email=email, full_name=full_name, type_id=type_id, password=password)

        
        try:
            db.session.add(new_user)
            db.session.flush()
            new_metadata = UserMetadata(user_id=new_user.user_id, phone_number=phone_number)

            db.session.add(new_metadata)
            db.session.commit()
            flash('Korisnik uspješno dodan!', 'success')
            return redirect('/admin_dashboard')
        except Exception as e:
            db.session.rollback()
            flash('Dogodila se greška prilikom dodavanja korisnika!', 'error')
            return redirect('/admin_dashboard')

    return render_template('add_user.html')

@app.route('/delete_user/<int:user_id>', methods=['POST'])
def delete_user(user_id):
    if 'user_id' not in session or session['type_id'] != 4:
        return jsonify({"success": False, "error": "Unauthorized"}), 403 

    user = Users.query.get(user_id)
    if not user:
        return jsonify({"success": False, "error": "User not found"}), 404

    try:
        Grades.query.filter_by(student_id=user_id).delete()
        TeacherSubjects.query.filter_by(user_id=user_id).delete()
        StudentSubjects.query.filter_by(user_id=user_id).delete()
        ParentStudents.query.filter((ParentStudents.parent_id == user_id) | (ParentStudents.student_id == user_id)).delete()
        UserMetadata.query.filter_by(user_id=user_id).delete()
        SubjectsWithMainTeacher.query.filter_by(main_teacher_id=user_id).delete()

        db.session.delete(user)
        db.session.commit()
        return jsonify({"success": True}), 200
    except Exception as e:
        db.session.rollback()
        print(f"Database error: {e}")
        return jsonify({"success": False, "error": "Database error"}), 500

if __name__ == "__main__":
    with app.app_context(): 
        db.create_all() 
    app.run(debug=True)